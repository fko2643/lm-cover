/* ── LM Cover Popup ─────────────────────────────────────── */

// ── Preset theme definitions ──────────────────────────────────────────
var PRESETS = [
  {
    id: 'sunset',
    name: 'Sunset Amber',
    colors: {
      bgPrimary: '#1a1008',
      bgHeader: '#241810',
      bgAiBubble: '#2e1f12',
      bgUserBubbleStart: '#ffe8c8',
      bgUserBubbleEnd: '#f0d4a0',
      bgInputStart: '#241810',
      bgInputEnd: '#1e140c',
      textPrimary: '#f0c878',
      textSecondary: 'rgba(240,200,120,0.65)',
      textMuted: 'rgba(240,200,120,0.48)',
      textUserBubble: '#3d2008',
      textAiBubble: '#f0c878',
      sendButton: '#e8983c',
      sendButtonIcon: '#1a1008',
      accent: '#e8983c',
      borderSubtle: 'rgba(232,152,60,0.08)',
      sidebarBg: '#1a1008',
      cardBg: '#241810',
      userBubbleShadow: '0 1px 3px rgba(0,0,0,0.14)',
    },
    swatches: ['#1a1008', '#2e1f12', '#ffe8c8', '#e8983c'],
  },
  {
    id: 'sepia',
    name: 'Sepia Dream',
    colors: {
      bgPrimary: '#1a1410',
      bgHeader: '#241e18',
      bgAiBubble: '#2d261f',
      bgUserBubbleStart: '#f4e4c1',
      bgUserBubbleEnd: '#e8d4a8',
      bgInputStart: '#241e18',
      bgInputEnd: '#1f1a14',
      textPrimary: '#e8d5b0',
      textSecondary: 'rgba(232,213,176,0.65)',
      textMuted: 'rgba(232,213,176,0.48)',
      textUserBubble: '#3d2b1f',
      textAiBubble: '#e8d5b0',
      sendButton: '#c4956a',
      sendButtonIcon: '#1a1410',
      accent: '#c4956a',
      borderSubtle: 'rgba(196,149,106,0.08)',
      sidebarBg: '#1a1410',
      cardBg: '#241e18',
      userBubbleShadow: '0 1px 3px rgba(0,0,0,0.1)',
    },
    swatches: ['#1a1410', '#2d261f', '#f4e4c1', '#c4956a'],
  },
  {
    id: 'forest',
    name: 'Forest Night',
    colors: {
      bgPrimary: '#0a1210',
      bgHeader: '#0f1c18',
      bgAiBubble: '#182a24',
      bgUserBubbleStart: '#dce8d4',
      bgUserBubbleEnd: '#c8dcc0',
      bgInputStart: '#0f1c18',
      bgInputEnd: '#0d1612',
      textPrimary: '#c8e6c0',
      textSecondary: 'rgba(200,230,192,0.65)',
      textMuted: 'rgba(200,230,192,0.48)',
      textUserBubble: '#1a3020',
      textAiBubble: '#c8e6c0',
      sendButton: '#5a8a4a',
      sendButtonIcon: '#ffffff',
      accent: '#7cb868',
      borderSubtle: 'rgba(124,184,104,0.08)',
      sidebarBg: '#0a1210',
      cardBg: '#0f1c18',
      userBubbleShadow: '0 1px 3px rgba(0,0,0,0.12)',
    },
    swatches: ['#0a1210', '#182a24', '#dce8d4', '#7cb868'],
  },
  {
    id: 'rose',
    name: 'Rose Quartz',
    colors: {
      bgPrimary: '#120c10',
      bgHeader: '#1c1418',
      bgAiBubble: '#2a1c24',
      bgUserBubbleStart: '#fce4ec',
      bgUserBubbleEnd: '#f0d0dc',
      bgInputStart: '#1c1418',
      bgInputEnd: '#161014',
      textPrimary: '#f0c8d8',
      textSecondary: 'rgba(240,200,216,0.65)',
      textMuted: 'rgba(240,200,216,0.48)',
      textUserBubble: '#3d1a28',
      textAiBubble: '#f0c8d8',
      sendButton: '#d4748c',
      sendButtonIcon: '#ffffff',
      accent: '#e890a8',
      borderSubtle: 'rgba(232,144,168,0.08)',
      sidebarBg: '#120c10',
      cardBg: '#1c1418',
      userBubbleShadow: '0 1px 3px rgba(0,0,0,0.12)',
    },
    swatches: ['#120c10', '#2a1c24', '#fce4ec', '#e890a8'],
  },
  {
    id: 'ocean',
    name: 'Ocean Deep',
    colors: {
      bgPrimary: '#080c14',
      bgHeader: '#0f1520',
      bgAiBubble: '#182030',
      bgUserBubbleStart: '#d0e0f8',
      bgUserBubbleEnd: '#bdd0f0',
      bgInputStart: '#0f1520',
      bgInputEnd: '#0b1018',
      textPrimary: '#b8cce8',
      textSecondary: 'rgba(184,204,232,0.65)',
      textMuted: 'rgba(184,204,232,0.48)',
      textUserBubble: '#0a1a30',
      textAiBubble: '#b8cce8',
      sendButton: '#4a80c0',
      sendButtonIcon: '#ffffff',
      accent: '#6098d8',
      borderSubtle: 'rgba(96,152,216,0.08)',
      sidebarBg: '#080c14',
      cardBg: '#0f1520',
      userBubbleShadow: '0 1px 3px rgba(0,0,0,0.14)',
    },
    swatches: ['#080c14', '#182030', '#d0e0f8', '#6098d8'],
  },
  {
    id: 'noir',
    name: 'Noir',
    colors: {
      bgPrimary: '#000000',
      bgHeader: '#0a0a0a',
      bgAiBubble: '#141414',
      bgUserBubbleStart: '#fafafa',
      bgUserBubbleEnd: '#e8e8e8',
      bgInputStart: '#0a0a0a',
      bgInputEnd: '#080808',
      textPrimary: '#e0e0e0',
      textSecondary: 'rgba(224,224,224,0.70)',
      textMuted: 'rgba(224,224,224,0.50)',
      textUserBubble: '#000000',
      textAiBubble: '#e0e0e0',
      sendButton: '#ffffff',
      sendButtonIcon: '#000000',
      accent: '#ffffff',
      borderSubtle: 'rgba(255,255,255,0.06)',
      sidebarBg: '#000000',
      cardBg: '#0a0a0a',
      userBubbleShadow: '0 1px 3px rgba(0,0,0,0.2)',
    },
    swatches: ['#000000', '#141414', '#fafafa', '#ffffff'],
  },
];

// ── Editable color fields grouped by category ─────────────────────────
var COLOR_GROUPS = [
  {
    name: 'Website',
    fields: [
      { key: 'bgPrimary',    label: 'Page Background' },
      { key: 'bgHeader',     label: 'Top Bar' },
      { key: 'sidebarBg',    label: 'Sidebar' },
      { key: 'textPrimary',  label: 'Primary Text' },
      { key: 'textSecondary',label: 'Subtitles & Taglines' },
      { key: 'bgInputStart', label: 'Message Input BG' },
      { key: 'sendButton',   label: 'Send Button' },
      { key: 'sendButtonIcon', label: 'Send Button Icon' },
    ],
  },
  {
    name: 'AI Bubble',
    fields: [
      { key: 'bgAiBubble',   label: 'Bubble Background' },
      { key: 'textAiBubble', label: 'Bubble Text' },
    ],
  },
  {
    name: 'User Bubble',
    fields: [
      { key: 'bgUserBubbleStart', label: 'Bubble BG (Top)' },
      { key: 'bgUserBubbleEnd',   label: 'Bubble BG (Bottom)' },
      { key: 'textUserBubble',    label: 'Bubble Text' },
    ],
  },
];

// ── State ─────────────────────────────────────────────────────────────
var currentTheme = null;
var currentPresetId = null;   // which preset is active, null if custom
var currentCustomId = null;   // which custom theme is active, null if preset
var customThemes = [];        // saved custom themes
var editingCustomId = null;   // currently editing this custom theme id

// ── DOM refs ──────────────────────────────────────────────────────────
var presetSelect     = document.getElementById('presetSelect');
var presetSwatches   = document.getElementById('presetSwatches');
var customThemesList = document.getElementById('customThemesList');
var customPanel      = document.getElementById('customPanel');
var toggleBtn        = document.getElementById('toggleCustom');
var colorFields      = document.getElementById('colorFields');
var themeNameInput   = document.getElementById('themeNameInput');
var saveCustomBtn    = document.getElementById('saveCustomBtn');
var exportBtn        = document.getElementById('exportBtn');
var importBtn        = document.getElementById('importBtn');
var importFile       = document.getElementById('importFile');
var resetBtn         = document.getElementById('resetBtn');
var statusMsg        = document.getElementById('statusMsg');
var activeThemeName  = document.getElementById('activeThemeName');

// ── Status message helper ─────────────────────────────────────────────
function showStatus(text, duration) {
  duration = duration || 1800;
  statusMsg.textContent = text;
  statusMsg.classList.add('visible');
  clearTimeout(statusMsg._timeout);
  statusMsg._timeout = setTimeout(function () {
    statusMsg.classList.remove('visible');
  }, duration);
}

// ── Edit mode helpers ───────────────────────────────────────────────────
function enterEditMode(customId, name, colors) {
  editingCustomId = customId;
  if (customPanel.hidden) {
    customPanel.hidden = false;
    toggleBtn.classList.add('open');
  }
  syncColorPickers(colors);
  themeNameInput.value = name;
  renderCustomThemes();
}

function exitEditMode() {
  editingCustomId = null;
  renderCustomThemes();
}

// ── Apply theme to the active tab ─────────────────────────────────────
function applyTheme(theme, presetId, customId) {
  currentTheme = theme;
  currentPresetId = presetId || null;
  currentCustomId = customId || null;

  // Switching to a different theme clears editing mode
  if (editingCustomId && editingCustomId !== customId) {
    exitEditMode();
  }

  activeThemeName.textContent = theme.name;

  // Update preset dropdown
  if (presetId) {
    presetSelect.value = presetId;
    updatePresetSwatches(presetId);
  } else {
    presetSelect.value = '';
    presetSwatches.innerHTML = '';
  }

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (tabs[0] && tabs[0].url && tabs[0].url.indexOf('loremate.ai') !== -1) {
      chrome.tabs.sendMessage(
        tabs[0].id,
        { type: 'APPLY_THEME', theme: theme },
        function () {}
      );
    }
  });

  chrome.storage.local.set({
    themeData: theme,
    activePresetId: currentPresetId,
    activeCustomId: currentCustomId,
    customThemes: customThemes,
  });

  if (!customPanel.hidden) {
    syncColorPickers(theme.colors);
  }

  renderCustomThemes();
}

// ── Render preset dropdown ────────────────────────────────────────────
function renderPresetDropdown(activePresetId) {
  presetSelect.innerHTML = '';

  // Placeholder when a custom theme is active
  var placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = '— Select a preset —';
  placeholder.disabled = true;
  if (!activePresetId) placeholder.selected = true;
  presetSelect.appendChild(placeholder);

  PRESETS.forEach(function (preset) {
    var opt = document.createElement('option');
    opt.value = preset.id;
    opt.textContent = preset.name;
    if (preset.id === activePresetId) opt.selected = true;
    presetSelect.appendChild(opt);
  });
}

// ── Update preset swatches preview ────────────────────────────────────
function updatePresetSwatches(presetId) {
  var preset = PRESETS.find(function (p) { return p.id === presetId; });
  if (!preset) {
    presetSwatches.innerHTML = '';
    return;
  }
  presetSwatches.innerHTML = '';
  preset.swatches.forEach(function (hex) {
    var dot = document.createElement('span');
    dot.className = 'preset-swatch-dot';
    dot.style.backgroundColor = hex;
    presetSwatches.appendChild(dot);
  });
}

// ── Render custom themes list ─────────────────────────────────────────
function renderCustomThemes() {
  customThemesList.innerHTML = '';

  if (customThemes.length === 0) {
    var empty = document.createElement('div');
    empty.className = 'custom-themes-empty';
    empty.textContent = 'No custom themes yet. Customize colors and save to create one.';
    customThemesList.appendChild(empty);
    return;
  }

  customThemes.forEach(function (ct) {
    var item = document.createElement('div');
    item.className = 'custom-theme-item';
    if (ct.id === currentCustomId) item.classList.add('active');

    // Click anywhere on the card to apply this theme
    item.addEventListener('click', function (e) {
      // Don't apply if the user clicked a button (Edit/Update/Del)
      if (e.target.closest('button')) return;
      var theme = JSON.parse(JSON.stringify(ct));
      theme._presetId = null;
      applyTheme(theme, null, ct.id);
      showStatus('Applied: ' + ct.name);
    });

    // Swatches preview
    var swatchesDiv = document.createElement('div');
    swatchesDiv.className = 'custom-theme-swatches';
    var previewColors = [
      ct.colors.bgPrimary,
      ct.colors.bgAiBubble,
      ct.colors.bgUserBubbleStart,
      ct.colors.accent,
    ];
    previewColors.forEach(function (hex) {
      var dot = document.createElement('span');
      dot.className = 'custom-theme-swatch';
      dot.style.backgroundColor = hex;
      swatchesDiv.appendChild(dot);
    });
    item.appendChild(swatchesDiv);

    // Name + actions row
    var row = document.createElement('div');
    row.className = 'custom-theme-row';

    var nameSpan = document.createElement('span');
    nameSpan.className = 'custom-theme-name';
    nameSpan.textContent = ct.name;
    row.appendChild(nameSpan);

    var actions = document.createElement('div');
    actions.className = 'custom-theme-actions';

    // Edit or Update button
    if (ct.id === editingCustomId) {
      var updateBtn = document.createElement('button');
      updateBtn.className = 'ct-btn ct-update';
      updateBtn.textContent = 'Update';
      updateBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        saveCustom();
      });
      actions.appendChild(updateBtn);
    } else {
      var editBtn = document.createElement('button');
      editBtn.className = 'ct-btn ct-edit';
      editBtn.title = 'Edit colors';
      editBtn.textContent = 'Edit';
      editBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        var theme = JSON.parse(JSON.stringify(ct));
        theme._presetId = null;
        applyTheme(theme, null, ct.id);
        enterEditMode(ct.id, ct.name, ct.colors);
      });
      actions.appendChild(editBtn);
    }

    // Delete button
    var delBtn = document.createElement('button');
    delBtn.className = 'ct-btn ct-delete';
    delBtn.title = 'Delete';
    delBtn.textContent = 'Del';
    delBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      deleteCustomTheme(ct.id);
    });
    actions.appendChild(delBtn);

    row.appendChild(actions);
    item.appendChild(row);
    customThemesList.appendChild(item);
  });
}

// ── Delete a custom theme ─────────────────────────────────────────────
function deleteCustomTheme(id) {
  customThemes = customThemes.filter(function (ct) { return ct.id !== id; });

  // If the deleted theme was active, switch to the first preset
  if (currentCustomId === id) {
    var def = JSON.parse(JSON.stringify(PRESETS[0]));
    def._presetId = PRESETS[0].id;
    applyTheme(def, PRESETS[0].id, null);
  }

  // If we were editing the deleted theme, clear editing state
  if (editingCustomId === id) {
    exitEditMode();
  }

  chrome.storage.local.set({ customThemes: customThemes });
  renderCustomThemes();
  showStatus('Theme deleted');
}

// ── Build color fields grouped by category ────────────────────────────
function buildColorFields() {
  colorFields.innerHTML = '';

  COLOR_GROUPS.forEach(function (group) {
    var header = document.createElement('div');
    header.className = 'color-group-header';
    header.textContent = group.name;
    colorFields.appendChild(header);

    group.fields.forEach(function (item) {
      var row = document.createElement('div');
      row.className = 'color-row';

      var label = document.createElement('label');
      label.textContent = item.label;
      row.appendChild(label);

      var picker = document.createElement('input');
      picker.type = 'color';
      picker.dataset.key = item.key;
      picker.addEventListener('input', onColorPickerChange);
      row.appendChild(picker);

      var hexInput = document.createElement('input');
      hexInput.type = 'text';
      hexInput.dataset.key = item.key;
      hexInput.maxLength = 30;
      hexInput.addEventListener('input', onHexInputChange);
      row.appendChild(hexInput);

      colorFields.appendChild(row);
    });

    if (group !== COLOR_GROUPS[COLOR_GROUPS.length - 1]) {
      var spacer = document.createElement('div');
      spacer.className = 'color-group-spacer';
      colorFields.appendChild(spacer);
    }
  });
}

function syncColorPickers(colors) {
  var rows = colorFields.querySelectorAll('.color-row');
  rows.forEach(function (row) {
    var picker = row.querySelector('input[type="color"]');
    var hex = row.querySelector('input[type="text"]');
    var key = picker.dataset.key;
    var value = colors[key] || '#000000';
    hex.value = value;

    var rgbMatch = value.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (rgbMatch) {
      var r = parseInt(rgbMatch[1], 10).toString(16).padStart(2, '0');
      var g = parseInt(rgbMatch[2], 10).toString(16).padStart(2, '0');
      var b = parseInt(rgbMatch[3], 10).toString(16).padStart(2, '0');
      picker.value = '#' + r + g + b;
    } else {
      picker.value = value;
    }
  });
}

// ── Color change handlers ─────────────────────────────────────────────
function onColorPickerChange(e) {
  var key = e.target.dataset.key;
  var value = e.target.value;
  var row = e.target.closest('.color-row');
  row.querySelector('input[type="text"]').value = value;
  currentTheme.colors[key] = value;
  applyTheme(currentTheme, currentPresetId, currentCustomId);
}

function onHexInputChange(e) {
  var key = e.target.dataset.key;
  var value = e.target.value.trim();
  if (!value) return;
  currentTheme.colors[key] = value;
  var row = e.target.closest('.color-row');
  var picker = row.querySelector('input[type="color"]');
  if (/^#[0-9a-fA-F]{6}$/.test(value)) {
    picker.value = value;
  }
  applyTheme(currentTheme, currentPresetId, currentCustomId);
}

// ── Toggle customize panel ────────────────────────────────────────────
function toggleCustomPanel() {
  var hidden = customPanel.hidden;
  customPanel.hidden = !hidden;
  if (hidden) {
    toggleBtn.classList.add('open');
    syncColorPickers(currentTheme.colors);

    // Pre-fill name: editing theme name, or current custom theme name, or empty
    if (editingCustomId) {
      var editTarget = customThemes.find(function (ct) { return ct.id === editingCustomId; });
      themeNameInput.value = editTarget ? editTarget.name : '';
    } else if (currentCustomId) {
      themeNameInput.value = currentTheme.name;
    } else {
      themeNameInput.value = '';
    }
  } else {
    toggleBtn.classList.remove('open');
  }
}

// ── Save as custom ────────────────────────────────────────────────────
function saveCustom() {
  var name = themeNameInput.value.trim() || 'My Theme';
  var theme = JSON.parse(JSON.stringify(currentTheme));
  theme.name = name;

  if (editingCustomId) {
    // Update existing custom theme
    var target = customThemes.find(function (ct) { return ct.id === editingCustomId; });
    if (target) {
      target.name = name;
      target.colors = theme.colors;
    }
    theme._presetId = null;
    applyTheme(theme, null, editingCustomId);
    exitEditMode();
    showStatus('Updated: ' + name);
  } else {
    // Create new custom theme
    var id = 'custom-' + Date.now();
    customThemes.push({
      id: id,
      name: name,
      colors: theme.colors,
    });
    theme._presetId = null;
    applyTheme(theme, null, id);
    showStatus('Saved: ' + name);
  }

  chrome.storage.local.set({ customThemes: customThemes });
  renderCustomThemes();
}

// ── Export ────────────────────────────────────────────────────────────
function exportTheme() {
  var exportData = JSON.parse(JSON.stringify(currentTheme));
  delete exportData._presetId;

  var blob = new Blob([JSON.stringify(exportData, null, 2)], {
    type: 'application/json',
  });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = 'lm-cover-theme-' + exportData.name.toLowerCase().replace(/\s+/g, '-') + '.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showStatus('Theme exported');
}

// ── Import ────────────────────────────────────────────────────────────
function importTheme(file) {
  var reader = new FileReader();
  reader.onload = function (e) {
    try {
      var data = JSON.parse(e.target.result);
      if (!data.colors || typeof data.colors !== 'object') {
        showStatus('Invalid theme file');
        return;
      }
      var merged = JSON.parse(JSON.stringify(PRESETS[0]));
      merged.colors = merged.colors || {};
      Object.keys(data.colors).forEach(function (k) {
        merged.colors[k] = data.colors[k];
      });
      merged.name = data.name || 'Imported Theme';
      merged._presetId = null;

      // Imported themes are always saved as custom
      var id = 'custom-' + Date.now();
      customThemes.push({
        id: id,
        name: merged.name,
        colors: merged.colors,
      });
      applyTheme(merged, null, id);
      chrome.storage.local.set({ customThemes: customThemes });
      renderCustomThemes();
      showStatus('Imported: ' + merged.name);
    } catch (err) {
      showStatus('Could not read file');
    }
  };
  reader.readAsText(file);
}

// ── Reset ─────────────────────────────────────────────────────────────
function resetToDefault() {
  var def = JSON.parse(JSON.stringify(PRESETS[0]));
  def._presetId = PRESETS[0].id;
  applyTheme(def, PRESETS[0].id, null);
  showStatus('Reset to ' + PRESETS[0].name);
}

// ── Init ──────────────────────────────────────────────────────────────
function init() {
  buildColorFields();

  // Preset dropdown change handler
  presetSelect.addEventListener('change', function () {
    var id = presetSelect.value;
    if (!id) return;
    var preset = PRESETS.find(function (p) { return p.id === id; });
    if (!preset) return;
    var theme = JSON.parse(JSON.stringify(preset));
    theme._presetId = preset.id;
    applyTheme(theme, preset.id, null);
    showStatus('Applied: ' + preset.name);
  });

  toggleBtn.addEventListener('click', toggleCustomPanel);
  saveCustomBtn.addEventListener('click', saveCustom);
  exportBtn.addEventListener('click', exportTheme);
  importBtn.addEventListener('click', function () {
    importFile.click();
  });
  importFile.addEventListener('change', function () {
    if (importFile.files[0]) {
      importTheme(importFile.files[0]);
      importFile.value = '';
    }
  });
  resetBtn.addEventListener('click', resetToDefault);

  // Load from storage
  chrome.storage.local.get(
    ['themeData', 'activePresetId', 'activeCustomId', 'customThemes'],
    function (result) {
      customThemes = result.customThemes || [];
      var presetId = result.activePresetId || null;
      var customId = result.activeCustomId || null;

      renderPresetDropdown(presetId);
      renderCustomThemes();

      if (result.themeData && result.themeData.colors) {
        currentTheme = result.themeData;
        currentPresetId = presetId;
        currentCustomId = customId;
        activeThemeName.textContent = result.themeData.name;

        // Update dropdown to match
        if (presetId) {
          presetSelect.value = presetId;
          updatePresetSwatches(presetId);
        } else {
          presetSelect.value = '';
        }

        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          if (tabs[0] && tabs[0].url && tabs[0].url.indexOf('loremate.ai') !== -1) {
            chrome.tabs.sendMessage(tabs[0].id, {
              type: 'APPLY_THEME',
              theme: result.themeData,
            });
          }
        });
      } else {
        // No stored theme — apply first preset as default
        var def = JSON.parse(JSON.stringify(PRESETS[0]));
        def._presetId = PRESETS[0].id;
        currentTheme = def;
        currentPresetId = PRESETS[0].id;
        currentCustomId = null;
        activeThemeName.textContent = PRESETS[0].name;
        presetSelect.value = PRESETS[0].id;
        updatePresetSwatches(PRESETS[0].id);

        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          if (tabs[0] && tabs[0].url && tabs[0].url.indexOf('loremate.ai') !== -1) {
            chrome.tabs.sendMessage(tabs[0].id, {
              type: 'APPLY_THEME',
              theme: def,
            });
          }
        });
      }
    }
  );
}

document.addEventListener('DOMContentLoaded', init);
