(function () {
  'use strict';

  // ── Default Theme: Sunset Amber ─────────────────────────────────
  const DEFAULT_THEME = {
    name: 'Sunset Amber',
    colors: {
      bgPrimary: '#1a1008',
      bgHeader: '#241810',
      bgAiBubble: '#2e1f12',
      bgUserBubbleStart: '#ffe8c8',
      bgUserBubbleEnd: '#f0d4a0',
      bgInputStart: '#241810',
      bgInputEnd: '#1e140c',
      textPrimary: '#f0c878',
      textSecondary: 'rgba(240,200,120,0.65)',
      textMuted: 'rgba(240,200,120,0.48)',
      textUserBubble: '#3d2008',
      textAiBubble: '#f0c878',
      sendButton: '#e8983c',
      sendButtonIcon: '#1a1008',
      accent: '#e8983c',
      borderSubtle: 'rgba(232,152,60,0.08)',
      sidebarBg: '#1a1008',
      cardBg: '#241810',
      userBubbleShadow: '0 1px 3px rgba(0,0,0,0.14)',
    },
  };

  let currentTheme = null;
  let observer = null;

  // Memoised native colors for mode detection. Kept across refreshes so
  // that streaming (which briefly leaves only one span type on screen)
  // doesn't lose the mode context.
  let lastActionNative = null;
  let lastSpeechNative = null;

  // ── Color helpers ────────────────────────────────────────────────────
  const _colorCanvas = document.createElement('canvas').getContext('2d');
  function toRgb(color) {
    if (!color) return '';
    try {
      _colorCanvas.fillStyle = '#000';
      _colorCanvas.fillStyle = color;
      const v = _colorCanvas.fillStyle;
      if (v.charAt(0) === '#') {
        const r = parseInt(v.slice(1, 3), 16);
        const g = parseInt(v.slice(3, 5), 16);
        const b = parseInt(v.slice(5, 7), 16);
        return 'rgb(' + r + ', ' + g + ', ' + b + ')';
      }
      return v;
    } catch (e) {
      return color;
    }
  }

  function luminance(rgbStr) {
    const m = (rgbStr || '').match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
    if (!m) return 0;
    return 0.299 * (+m[1]) + 0.587 * (+m[2]) + 0.114 * (+m[3]);
  }

  function lightenHex(hex, factor) {
    if (!hex || hex.charAt(0) !== '#') return '#202020';
    var r, g, b;
    if (hex.length === 7) {
      r = parseInt(hex.slice(1, 3), 16);
      g = parseInt(hex.slice(3, 5), 16);
      b = parseInt(hex.slice(5, 7), 16);
    } else if (hex.length === 4) {
      r = parseInt(hex.charAt(1) + hex.charAt(1), 16);
      g = parseInt(hex.charAt(2) + hex.charAt(2), 16);
      b = parseInt(hex.charAt(3) + hex.charAt(3), 16);
    } else {
      return '#202020';
    }
    r = Math.round(r + (255 - r) * factor);
    g = Math.round(g + (255 - g) * factor);
    b = Math.round(b + (255 - b) * factor);
    return '#' +
      r.toString(16).padStart(2, '0') +
      g.toString(16).padStart(2, '0') +
      b.toString(16).padStart(2, '0');
  }

  // ── Static CSS ───────────────────────────────────────────────────────
  function generateStaticCSS(c) {
    var sidebarAccent = lightenHex(c.sidebarBg, 0.09);
    return `
/* ── LM Cover static styles ── */

html { background-color: ${c.bgPrimary} !important; }
body { background-color: ${c.bgPrimary} !important; }
main[style*="background-color"] {
  background-color: ${c.bgPrimary} !important;
}

[aria-hidden="true"][class*="bg-\\[\\#161616\\]"] {
  background-color: ${c.bgHeader} !important;
}

[style*="--chat-viewport-height"] {
  background-color: ${c.bgPrimary} !important;
}

[class*="bg-\\[\\#080808\\]"] {
  background-color: ${c.bgPrimary} !important;
}

[class*="from-\\[\\#181818\\]"] {
  background-image: linear-gradient(to bottom, ${c.bgInputStart}, ${c.bgInputEnd}) !important;
}

button[aria-label="Send message"] {
  background-color: ${c.sendButton} !important;
}
button[aria-label="Send message"] svg {
  color: ${c.sendButtonIcon} !important;
}

[data-sidebar][class*="bg-\\[\\#161616\\]"] {
  background-color: ${c.sidebarBg} !important;
}
[data-sidebar][class*="bg-\\[\\#080808\\]"] {
  background-color: ${c.sidebarBg} !important;
}
.bg-sidebar {
  background-color: ${c.sidebarBg} !important;
}
[data-sidebar="trigger"][class*="bg-\\[\\#202020\\]"] {
  background-color: ${sidebarAccent} !important;
}

.text-white:not(button[aria-label="Send message"] svg),
.text-white\\/100 { color: ${c.textPrimary} !important; }
.text-white\\/70 { color: ${c.textSecondary} !important; }
.text-white\\/65 { color: ${c.textSecondary} !important; }
.text-white\\/55 { color: ${c.textMuted} !important; }
.text-white\\/45 { color: ${c.textMuted} !important; }

[class*="bg-\\[\\#161616\\]"] {
  background-color: ${c.cardBg} !important;
}

[class*="border-white\\/5"] {
  border-color: ${c.borderSubtle} !important;
}

.text-white\\/80 { color: ${c.textPrimary} !important; }
.hover\\:text-white\\/80:hover { color: ${c.textPrimary} !important; }
.hover\\:text-white\\/85:hover { color: ${c.textPrimary} !important; }
.hover\\:text-white\\/90:hover { color: ${c.textPrimary} !important; }

::-webkit-scrollbar-thumb {
  background-color: ${c.cardBg} !important;
}

[class*="bg-\\[\\#161616\\]"],
[style*="background-color: rgb(22, 22, 22)"] {
  background-color: ${c.cardBg} !important;
}

[class*="bg-\\[\\#181818\\]"] {
  background-color: ${c.cardBg} !important;
}

.text-zinc-500 { color: ${c.textMuted} !important; }

[class*="bg-gradient-to-b"][class*="pointer-events-none"],
[class*="bg-gradient-to-t"][class*="pointer-events-none"] {
  background-image: none !important;
}

[class*="grid-cols"] > .flex.flex-col.rounded-xl {
  background-color: ${c.cardBg} !important;
  border-color: ${c.borderSubtle} !important;
}
.text-zinc-50 { color: ${c.textPrimary} !important; }
.text-zinc-400 { color: ${c.textSecondary} !important; }
[class*="col-span-full"] { color: ${c.textMuted} !important; }

/* Message names */
[data-message-id] .justify-end + * [class*="text-neutral-300"] {
  color: ${c.textSecondary} !important;
}
[data-message-id] .flex.flex-row:not(.justify-end) [class*="my-\\[6px\\]"] a {
  color: ${c.textPrimary} !important;
}
`;
  }

  // ── Dynamic CSS ──────────────────────────────────────────────────────
  // Depends on detected mode + LoreMate's native colors. Uses attribute
  // selectors (data-lm-bubble, data-lm-span-type) so React re-renders
  // don't blow away the styling — the tags survive as long as the DOM
  // node does, and CSS reapplies automatically.
  function generateDynamicCSS(c, mode, actionNative, speechNative) {
    const bg = c.bgAiBubble;
    const user = c.textAiBubble;
    const actionDim = actionNative || 'rgb(209, 213, 219)';
    const speechDim = speechNative || 'rgb(209, 213, 219)';

    let css = `
/* ── LM Cover dynamic styles ── */

/* AI bubble shell */
[data-lm-bubble="ai"] {
  background-color: ${bg} !important;
  background-image: none !important;
  color: ${user} !important;
}

/* User bubble shell */
[data-lm-bubble="user"] {
  background-color: transparent !important;
  background-image: linear-gradient(to bottom, ${c.bgUserBubbleStart}, ${c.bgUserBubbleEnd}) !important;
  box-shadow: ${c.userBubbleShadow} !important;
}
[data-lm-bubble="user"] span[style*="color"] {
  color: ${c.textUserBubble} !important;
}
`;

    if (mode === 'none') {
      css += `
/* None mode: everything is user color */
[data-lm-bubble="ai"] span[style*="color"],
[data-lm-bubble="ai"] [data-lm-span-type] {
  color: ${user} !important;
}
`;
    } else if (mode === 'action') {
      css += `
/* Action mode: action = user color, speech = dim.
   Untagged spans (transient during streaming, before the first
   refresh reaches them) are treated as action — matches the
   overwhelming majority of cases and only mispaints for a single
   frame when a new speech span appears. */
[data-lm-bubble="ai"] [data-lm-span-type="action"],
[data-lm-bubble="ai"] span[style*="color"]:not([data-lm-span-type]) {
  color: ${user} !important;
}
[data-lm-bubble="ai"] [data-lm-span-type="speech"] {
  color: ${speechDim} !important;
}
`;
    } else if (mode === 'speech') {
      css += `
/* Speech mode: speech = user color, action = dim.
   Untagged spans default to action (dim) for the same reason. */
[data-lm-bubble="ai"] [data-lm-span-type="speech"] {
  color: ${user} !important;
}
[data-lm-bubble="ai"] [data-lm-span-type="action"],
[data-lm-bubble="ai"] span[style*="color"]:not([data-lm-span-type]) {
  color: ${actionDim} !important;
}
`;
    }

    return css;
  }

  // ── Style elements ───────────────────────────────────────────────────
  let staticStyleEl = null;
  let dynamicStyleEl = null;

  function injectStaticCSS(theme) {
    if (!staticStyleEl) {
      staticStyleEl = document.createElement('style');
      staticStyleEl.id = 'lm-cover-static';
      (document.head || document.documentElement).appendChild(staticStyleEl);
    }
    staticStyleEl.textContent = generateStaticCSS(theme.colors);
  }

  function updateDynamicCSS(css) {
    if (!dynamicStyleEl) {
      dynamicStyleEl = document.createElement('style');
      dynamicStyleEl.id = 'lm-cover-dynamic';
      (document.head || document.documentElement).appendChild(dynamicStyleEl);
    }
    if (dynamicStyleEl.textContent !== css) {
      dynamicStyleEl.textContent = css;
    }
  }

  // ── Refresh: tag bubbles/spans + detect mode + update dynamic CSS ────
  function refresh() {
    if (!currentTheme) return;
    const c = currentTheme.colors;
    const userColorRgb = toRgb(c.textAiBubble);

    let observedActionNative = null;
    let observedSpeechNative = null;

    const bubbles = document.querySelectorAll('[class*="rounded-\\[28px\\]"]');
    bubbles.forEach(function (bubble) {
      if (!bubble.closest('[data-message-id]')) return;
      const row = bubble.closest('.flex.flex-row');
      if (!row) return;

      const isUser = row.classList.contains('justify-end');
      const wantTag = isUser ? 'user' : 'ai';
      if (bubble.dataset.lmBubble !== wantTag) {
        bubble.dataset.lmBubble = wantTag;
      }
      if (isUser) return;

      // Tag AI spans.
      // Rule: any span whose visible text starts with a double quote is
      // speech; everything else is action. We DON'T require <em>/<i> for
      // action — LoreMate emits plain-text action spans when the model
      // doesn't produce italics, and requiring em/i would drop those
      // into the "speech dim" bucket in Action mode.
      const spans = bubble.querySelectorAll('span[style*="color"]');
      spans.forEach(function (s) {
        const type =
          s.textContent.trim().charAt(0) === '"' ? 'speech' : 'action';
        if (s.dataset.lmSpanType !== type) {
          s.dataset.lmSpanType = type;
        }

        // Read LoreMate's native color straight from inline style.
        // Because we don't overwrite span inline styles any more,
        // this always reflects LoreMate's current opinion.
        const cur = toRgb(s.style.color);
        if (!cur || cur === userColorRgb) return;
        if (type === 'action' && !observedActionNative) observedActionNative = cur;
        if (type === 'speech' && !observedSpeechNative) observedSpeechNative = cur;
      });
    });

    // Merge observations with memoised values so streaming's transient
    // "only action visible so far" state still resolves the right mode.
    if (observedActionNative) lastActionNative = observedActionNative;
    if (observedSpeechNative) lastSpeechNative = observedSpeechNative;

    let mode = 'none';
    if (
      lastActionNative &&
      lastSpeechNative &&
      lastActionNative !== lastSpeechNative
    ) {
      mode =
        luminance(lastActionNative) > luminance(lastSpeechNative)
          ? 'action'
          : 'speech';
    }

    updateDynamicCSS(generateDynamicCSS(c, mode, lastActionNative, lastSpeechNative));
  }

  // ── Refresh scheduling ───────────────────────────────────────────────
  // Collapse many quick mutations (typical during streaming) into one
  // pass per animation frame. Cheap: only DOM reads + a data-attribute
  // write + at most one text swap on <style>.
  let rafId = null;
  function scheduleRefresh() {
    if (rafId != null) return;
    rafId = requestAnimationFrame(function () {
      rafId = null;
      refresh();
    });
  }

  // ── MutationObserver ─────────────────────────────────────────────────
  function startMessageObserver() {
    observer = new MutationObserver(function (mutations) {
      let interesting = false;
      for (let i = 0; i < mutations.length; i++) {
        const m = mutations[i];
        if (m.type === 'childList') {
          if (m.addedNodes.length > 0 || m.removedNodes.length > 0) {
            interesting = true;
            break;
          }
        } else if (m.type === 'attributes' && m.attributeName === 'style') {
          const t = m.target;
          if (t.nodeType === 1) {
            interesting = true;
            break;
          }
        }
      }
      if (interesting) scheduleRefresh();
    });

    function tryObserve() {
      if (document.body) {
        observer.observe(document.body, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ['style'],  // ignore our own data-* writes
        });
      } else {
        setTimeout(tryObserve, 50);
      }
    }
    tryObserve();
  }

  // ── Apply theme (from popup or initial storage load) ─────────────────
  function applyTheme(theme) {
    currentTheme = theme;
    injectStaticCSS(theme);
    refresh();
  }

  // ── Init ─────────────────────────────────────────────────────────────
  function init() {
    startMessageObserver();
    chrome.storage.local.get(['themeData'], function (result) {
      if (result.themeData && result.themeData.colors) {
        applyTheme(result.themeData);
      } else {
        applyTheme(DEFAULT_THEME);
      }
    });
  }

  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.type === 'APPLY_THEME') {
      applyTheme(message.theme);
      sendResponse({ success: true });
    } else if (message.type === 'GET_CURRENT_THEME') {
      sendResponse({ theme: currentTheme || DEFAULT_THEME });
    }
    return true;
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
